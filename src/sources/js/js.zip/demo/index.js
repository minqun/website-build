let img = new Image()
img.src = require('../../images/u27.png');
export default {
    name: 'test'
}
