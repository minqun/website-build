export default {
    name: 'detail'
}
