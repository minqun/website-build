export default {
    name: 'index'
}
